#/bin/bash
/usr/bin/minidlnad -f /data/configuration/miscellanea/volumiominidlna/minidlna.conf