#!/bin/bash

echo "Unistalling Volumio mini dlna dependencies"

echo "Removing Volumio mini dlna"



sudo apt-get purge --auto-remove minidlna
echo "Done"
echo "pluginuninstallend"