#!/bin/bash

echo "Unistalling Volumio mini dlna dependencies"

echo "Removing Volumio mini dlna"

echo "Done"
echo "pluginuninstallend"