April 3rd 2017

This plugin is a easy way to install and configure minilna server on volumio
It is just a first work and it may not work as expected or lack of option.

Installation

- Just download volumiominidlna.zip and drop it plugin install page of volumio

