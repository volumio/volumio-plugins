#!/bin/bash

echo "Installing volumio mini-dlna dependencies"
sudo apt-get update
sudo apt-get -y install minidlna
#cd /data/plugins/miscellanea/volumiominidlna
#		cd /
#		sudo tar -xvf minidlna.tar.xz -C /
echo "plugininstallend"
