#!/bin/bash

# Uninstall dependendencies
# apt-get remove -y
rm -R /data/plugins/miscellanea/fmxmtr
rm -R /data/configuration/miscellanea/fmxmtr
echo "Done"
echo "pluginuninstallend"