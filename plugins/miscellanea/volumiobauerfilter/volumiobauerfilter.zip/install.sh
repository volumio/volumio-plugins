#!/bin/bash

echo "Installing volumiobauerfilter dependencies"
#sudo apt-get update
#sudo apt-get -y install bsb2-ladspa
#required to end the plugin install
echo "plugininstallend"
