23 JULLY 2016
	VOLUMIO BAUER FILTER PLUGIN


This plugin is designed to use provide Bauer filter to Volumio
To start it is a very basic plugin.
