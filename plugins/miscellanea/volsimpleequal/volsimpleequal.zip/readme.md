folder for volsimpleequal volumio simple equalizer
based on alsaequal
NOTHING USEABLE YET!

01st July 
- nearly working - but output mdp doesn't work