
2nd July 2017
folder for volsimpleequal volumio simple equalizer
based on alsaequal
NOTHING USEABLE YET!

2nd July
- working version ! But Presets non working...

01st July 
- nearly working - but output mdp doesn't work