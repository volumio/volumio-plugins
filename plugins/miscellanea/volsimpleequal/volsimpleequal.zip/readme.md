04 july



folder for volsimpleequal volumio simple equalizer
based on alsaequal
Can't work with softvol !!!!
NOTHING USEABLE YET!

04th July
- correction in install.sh

03rd July
- add onStop promise
- plugequal instead of equal

2nd July
- working version ! But Presets non working...

01st July 
- nearly working - but output mdp doesn't work