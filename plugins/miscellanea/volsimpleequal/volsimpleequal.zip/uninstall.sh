#!/bin/bash

echo "Unistalling volsimpleequal dependencies"

echo "Removing volsimpleequal"

echo "Done"
echo "pluginuninstallend"