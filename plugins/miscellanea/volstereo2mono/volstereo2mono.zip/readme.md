20th November 2017


		Volstereo2mono Downmix stereo to mono

Can't work with softvol !!!!

Requirement

 A working well configured volumio > 2.041

How to install ?

 Download volstereo2mono.zip and drop it in the "updload a plugin" zone of volumio.
 Enable it and... enjoy

note : if no sound don't change anything in volumio settings. Reboot and try to play a track.

What is working ?

-

What is not working

-
20th november

- first commit

