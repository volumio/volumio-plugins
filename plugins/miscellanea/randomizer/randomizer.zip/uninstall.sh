#!/bin/bash

# Uninstall dependendencies
# apt-get remove -y socket.io-client@^1.7.4

echo "Done"
echo "pluginuninstallend"
