17th Sepetember 2017

This plugin plays the queue when a specific IP is detected the first time on the network and stop plyaing when the ip diseappears.
It means that for example, if you configure the iP of your smartphone in the plugin, when your back home, it starts to play the queue.
And if you leave, it stops the playing.



17 th september
- working version

16 th september
- correct  service

11 th september
- second commit....


10 th september

- first commit