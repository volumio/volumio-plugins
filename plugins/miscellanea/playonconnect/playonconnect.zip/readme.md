22th Sepetember 2017

This plugin plays a given playlist when a specific IP is detected the first time on the network and stop playing when the ip disappears.
It means that for example, if you configure the iP of your smartphone in the plugin, when your back home, it starts to play the playlist.
And if you leave, it stops the playing.

22th september

- now play a given playlist

17 th september
- working version

16 th september
- correct  service

11 th september
- second commit....


10 th september

- first commit