#!/bin/bash

sudo rm /etc/systemd/system/peppy.service

echo "Done"
echo "pluginuninstallend"
