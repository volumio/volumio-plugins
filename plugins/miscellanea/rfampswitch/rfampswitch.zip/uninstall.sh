#!/bin/bash

echo "pluginuninstallend"
