#!/bin/bash

echo "plugininstallend"
