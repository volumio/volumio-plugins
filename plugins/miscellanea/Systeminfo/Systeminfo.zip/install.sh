#!/bin/bash
echo "Installing systeminfo"

#required to end the plugin install
echo "plugininstallend"
