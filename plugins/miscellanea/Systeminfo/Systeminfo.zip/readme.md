November 15th

This plugin returns informations about your system such as cpu, mem, kernel...



![Alt text](Systeminffos.png?raw=true "Systeminfos window")


###  Download and install the plugin

Type the following commands to download and install plugin:

```
wget https://github.com/balbuze/volumio-plugins/raw/master/plugins/miscellanea/Systeminfo/Systeminfo.zip
mkdir ./Systeminfo
miniunzip Systeminfo.zip -d ./Systeminfo
cd ./Systeminfo
volumio plugin install
cd ..
rm -Rf Systeminfo*
```


- first commit
