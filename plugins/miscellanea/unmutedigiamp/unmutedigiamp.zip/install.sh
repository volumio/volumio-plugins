#!/bin/bash

echo "Installing "
echo "Installing unmutedigiamp"


#requred to end the plugin install
echo "plugininstallend"
