#!/bin/bash

echo "Installing "
echo "Installing unmutedigiamp"
echo "Installing WiringPi"


#requred to end the plugin install
echo "plugininstallend"
