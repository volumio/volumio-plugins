#!/bin/bash

echo "Unistalling Unmutedigiamp dependencies"

echo "Removing Unmutedigiamp"

echo "Done"
