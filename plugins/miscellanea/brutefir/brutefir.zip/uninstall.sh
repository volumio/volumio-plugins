#!/bin/bash

echo "Unistalling Brutefir dependencies"

echo "Removing Brutefir"

echo "Done"
