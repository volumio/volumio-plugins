filters for testing
to be used with S32_LE as filter format