#!/bin/bash

echo "Initializing config"


echo "plugininstallend"
