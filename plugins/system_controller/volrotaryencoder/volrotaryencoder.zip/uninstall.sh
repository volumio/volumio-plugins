#!/bin/bash

echo "Unistalling volumio rotary encoder"

echo "Done"
echo "pluginuninstallend"