16th July 2017

Rotary encoder plugin for volumio