#!/bin/bash
echo "Installing volumio rotary encoder"

#required to end the plugin install
echo "plugininstallend"
