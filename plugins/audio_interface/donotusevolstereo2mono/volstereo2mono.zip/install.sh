#!/bin/bash

echo "Installing volstereo2mono dependencies"
echo "unload Loopback module if exists"
#required to end the plugin install
echo "plugininstallend"
