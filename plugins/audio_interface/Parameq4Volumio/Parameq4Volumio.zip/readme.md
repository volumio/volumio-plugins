Febuary 20th 2021


##  Experimental version for modular_alsa !




This plugin is designed to apply a Parametric Eq based on CamillaDsp

![Alt text](Parameq4Volumio.png?raw=true "Main interface")




## INSTALLATION WARNING

First, you must have a working configuration with volumio.

#
## To install

### 1. Enable SSH and connect to Volumio

To do that, have a look here : [ssh in volumio](https://volumio.github.io/docs/User_Manual/SSH.html)

### 2. Download and install the plugin

Type the following commands to download and install plugin:

```

```

### 3. Using the plugin

In webUI, enable the plugin.

## What is working :

nearly everythings


## What is not working :
?
- 

### 4. Last changes

Febuary 20th 2021

- 14 eq
- adapativ UI

Febuary 19th 2021

- equalizer scope

Febuary 17th 2021

- add lowpass and highpass filters
- attenuation fix

Febuary 15th 2021

- first usable (?) version
- autoset attenuation
- misc fixes

Febuary 12th 2021
- 
