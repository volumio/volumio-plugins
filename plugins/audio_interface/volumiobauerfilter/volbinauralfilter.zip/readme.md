24th November 2017
	VOLUMIO BAUER FILTER PLUGIN


This plugin is designed to provide Bauer filter to Volumio
It use bs2b-ladspa plugin
More info : http://bs2b.sourceforge.net/

How to install
Just download volbinauralfilter.zip and drop it in the plugin installation page in volumio.
Enable it. That it !
But you can change the default value of cut-off frequency and crossfeed level
"frequency" and "attenuation".


Last change

24th november 17

- first commit



