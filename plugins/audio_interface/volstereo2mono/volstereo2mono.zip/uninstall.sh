#!/bin/bash

echo "Unistalling volstereo2mono dependencies"

echo "Removing volstereo2mono"

echo "Done"
echo "pluginuninstallend"
