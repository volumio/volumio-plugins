 06th January 18


# Volstereo2mono Downmixes stereo to mono

## Can't work with softvol !!!!

Requirement

 A working well configured volumio > 2.041

## How to install ?

 Download volstereo2mono.zip and drop it in the "updload a plugin" zone of volumio.
 Enable it and... enjoy

note : if no sound don't change anything in volumio settings. Reboot and try to play a track.

## Last changes

06th January 18

- add a switch to toggle streo / mono

21 th november

- move to audio_interface category
- set volume to 0.7 in asound to avoid saturation

20th november

- first commit

