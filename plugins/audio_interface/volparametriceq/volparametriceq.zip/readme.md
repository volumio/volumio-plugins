02nd December 2017
	VOLUMIO PARAMETRIC EQUALIZER

DO NOT USE YET!

This plugin is designed to provide a parametric equalizer to Volumio
It uses caps ladspa plugin
http://quitte.de/dsp/caps.html#EqFA4p
More info : http://bs2b.sourceforge.net/

![Alt text](volparametriceq.png?raw=true "Parametric Equalizer")
How to install
Just download volparametriceq.zip and drop it in the plugin installation page in volumio.
Enable it. That it !


Last change

29th november 17

- first commit



