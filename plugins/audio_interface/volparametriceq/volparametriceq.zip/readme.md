030th January 18
#	VOLUMIO PARAMETRIC EQUALIZER

This plugin is designed to provide a parametric equalizer to Volumio.
It uses caps ladspa plugin
http://quitte.de/dsp/caps.html#EqFA4p
More info : http://bs2b.sourceforge.net/

![Alt text](volparametriceq.jpg?raw=true "Parametric Equalizer")

## NOT compatible with softvol!

## How to install

- Just download volparametriceq.zip and drop it in the plugin installation page in volumio.
Enable it. That it !


Tested on :
RPI2
PINE64


## Last changes

30th January 18
- more precise step for more precise settings....

02nd January 18
- update readme.md

28th december 17
- move switch to the bottom of the page

27th december 17

- correction for unsaved parameter for mid high db
- change index.js for autoconfig
- switch to enable /disable eq

09th december 17

- localization

03rd december 17
- update readme

29th november 17
- second commit (cosmetic)
- first commit
