Peppy alsa pipe
provide a peppyalsa pipe
in /tmp/myfifopeppy
