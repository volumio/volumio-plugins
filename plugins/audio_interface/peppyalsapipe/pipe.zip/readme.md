Peppy alsa pipe + peppyMeter 
installation for Volumio 
