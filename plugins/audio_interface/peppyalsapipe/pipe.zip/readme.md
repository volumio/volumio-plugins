Peppy alsa pipe
