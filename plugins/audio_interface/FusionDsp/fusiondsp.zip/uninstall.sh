#!/bin/bash

echo "Unistalling Brutefir dependencies"

echo "Removing CamillaDsp"

echo "Done"
echo "pluginuninstallend"