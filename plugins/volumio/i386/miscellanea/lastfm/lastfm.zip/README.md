# volumio-lastfm-plugin
Plugin to scrobble music played in Volumio 2.x to LastFM.

Also features a similar artists/tracks function in the browse section.