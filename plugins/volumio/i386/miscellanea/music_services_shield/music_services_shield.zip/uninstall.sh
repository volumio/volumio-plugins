#!/bin/bash

# Uninstall dependendencies
apt-get remove -y cpuset

echo "Done"
echo "pluginuninstallend"
