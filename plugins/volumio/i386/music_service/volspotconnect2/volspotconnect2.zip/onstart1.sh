#!/bin/bash
/usr/bin/curl "localhost:3000/api/v1/commands/?cmd=stop"
#OPtionnal :enter command you want to execute when librespot start
