#!/bin/bash
chmod +x /data/plugins/music_service/jellyfin/scripts/fix_mpd_bbc
echo "Jellyfin plugin installed"
