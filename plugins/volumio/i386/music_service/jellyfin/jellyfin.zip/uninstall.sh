#!/bin/bash
echo "Jellyfin plugin uninstalled"
