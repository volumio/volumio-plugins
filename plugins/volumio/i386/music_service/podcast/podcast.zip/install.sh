#!/bin/bash

echo "Installing Podcast plugin"

#requred to end the plugin install
echo "plugininstallend"