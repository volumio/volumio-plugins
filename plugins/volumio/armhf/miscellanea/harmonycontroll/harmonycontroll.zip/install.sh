#!/bin/bash

echo "Installing harmonycontroll Dependencies"
sudo apt-get update
# Install the required packages via apt-get
sudo npm install forever -g
sudo apt-get install unzip

echo "harmony-api downloading"
wget -O harmony-api.zip "https://github.com/maddox/harmony-api/archive/2.3.5.zip"
unzip_name="$(unzip -Z -1 harmony-api.zip | head -1 | rev | cut -c 2- | rev)"

echo "harmony-api unziping"
unzip harmony-api.zip
rm harmony-api.zip

mv $unzip_name harmony-api

echo "harmony-api bootstrap"
./harmony-api/script/bootstrap

#requred to end the plugin install
echo "plugininstallend"
