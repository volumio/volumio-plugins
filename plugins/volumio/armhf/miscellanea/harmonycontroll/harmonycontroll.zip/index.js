'use strict';

var libQ = require('kew');
var io = require('socket.io-client');
var fs=require('fs-extra');
var config = new (require('v-conf'))();
var exec = require('child_process').exec;
var execSync = require('child_process').execSync;
var axios = require('axios');

var socket = io.connect('http://localhost:3000');

//declare global status variable
var status = 'na';
var harmonyApiServer

module.exports = harmonycontroll;
function harmonycontroll(context) {
	var self = this;

	this.context = context;
	this.commandRouter = this.context.coreCommand;
	this.logger = this.context.logger;
	this.configManager = this.context.configManager;

	self.logger.harmonycontroll = function(data) {
		self.logger.info('[HarmonyControll] ' + data)
	};
}

harmonycontroll.prototype.onVolumioStart = function() {
	var self = this;
	var configFile=this.commandRouter.pluginManager.getConfigurationFile(this.context,'config.json');
	this.config = new (require('v-conf'))();
	this.config.loadFile(configFile);

  return libQ.resolve();
}

harmonycontroll.prototype.onStart = function() {
  var self = this;
	var defer=libQ.defer();

	harmonyApiServer = exec(__dirname + '/harmony-api/script/server', {uid:1000,gid:1000},
        function (error, stdout, stderr) {
            if(error != null) {
                self.logger.harmonycontroll('Error harmony-api start: '+error);
								defer.reject(error);
            } else {
                self.logger.harmonycontroll('harmony-api correctly started');

								// read and parse status once
								socket.emit('getState','');
								socket.once('pushState', self.parseStatus.bind(self));

								// listen to every subsequent status report from Volumio
								// status is pushed after every playback action, so we will be
								// notified if the status changes
								socket.on('pushState', self.parseStatus.bind(self));

                defer.resolve();
            }
			});

	harmonyApiServer.on('close', (code, signal) => {
		self.logger.harmonycontroll('harmony-api correctly ended');
	})

  return defer.promise;
};

harmonycontroll.prototype.onStop = function() {
    var self = this;
    var defer=libQ.defer();

		harmonyApiServer.kill();

    defer.resolve();

    return libQ.resolve();
};

harmonycontroll.prototype.onRestart = function() {
    var self = this;
    // Optional, use if you need it
};

harmonycontroll.prototype.parseStatus = function(state) {
    var self = this;
		self.logger.harmonycontroll('CurState: ' + state.status + ' PrevState: ' + status);

		var hubSlug = self.config.get('hubSlug');
		var activitySlug = self.config.get('activitySlug');

		self.logger.harmonycontroll('Hub slug: ' + hubSlug + ' activity slug: ' + activitySlug);

    if(state.status=='play' && state.status!=status) {
			clearTimeout(self.OffTimerID);

			axios.get('http://127.0.0.1:8282/hubs/'+hubSlug+'/status')
  		.then(response => {
				var json = response.data;
				self.logger.harmonycontroll("harmony status success:\n" + json);

				if(json['off'] == true || json['current_activity']['slug'] != activitySlug) {
					axios.post('http://127.0.0.1:8282/hubs/'+hubSlug+'/activities/'+activitySlug)
					.then(response => {
						self.logger.harmonycontroll("harmony activity start success");
					})
					.catch(error => {
						self.logger.harmonycontroll('harmony activity start error ' + error);
					});
				}
  		})
  		.catch(error => {
				self.logger.harmonycontroll('harmony status error ' + error);
  		});
    } else if((state.status=='pause' || state.status=='stop') && status=='play'){
			var offDelay = self.config.get('sleepDelayAfterStop');
			self.logger.harmonycontroll('InitTimeout - Activity off in: ' + offDelay + ' s');
			self.OffTimerID = setTimeout(function() {
				axios.get('http://127.0.0.1:8282/hubs/'+hubSlug+'/status')
	  		.then(response => {
					var json = response.data;
					self.logger.harmonycontroll("harmony status success");

					if(json['current_activity']['slug'] == activitySlug) {
						axios.put('http://127.0.0.1:8282/hubs/'+hubSlug+'/off')
						.then(response => {
							self.logger.harmonycontroll("harmony activity stop success");
						})
						.catch(error => {
							self.logger.harmonycontroll('harmony activity stop error ' + error);
						});
					}
	  		})
	  		.catch(error => {
					self.logger.harmonycontroll('harmony status error ' + error);
	  		});
			}, offDelay * 1000);
    }

		status = state.status;
};


// Configuration Methods -----------------------------------------------------------------------------

harmonycontroll.prototype.getUIConfig = function() {
    var defer = libQ.defer();
    var self = this;

    var lang_code = this.commandRouter.sharedVars.get('language_code');

		var currentDelay = self.config.get('sleepDelayAfterStop');
		var currentHubSlug = self.config.get('hubSlug');
		var currentActivitySlug = self.config.get('activitySlug');

    self.commandRouter.i18nJson(__dirname+'/i18n/strings_'+lang_code+'.json',
        __dirname+'/i18n/strings_en.json',
        __dirname + '/UIConfig.json')
        .then(function(uiconf)
        {
					uiconf.sections[0].content[1].value = currentDelay;

					axios.get('http://127.0.0.1:8282/hubs')
		  		.then(response => {
						var hubsJson = response.data;
						self.logger.harmonycontroll("harmony hubs list success | JSON:\n" + JSON.stringify(hubsJson));

						var hubs = hubsJson['hubs'];
						for (let hub of hubs) {
							var hubName = hub.replace('-', ' ');

							axios.get('http://127.0.0.1:8282/hubs/'+hub+'/activities')
							.then(response => {
								var activityJson = response.data;
								self.logger.harmonycontroll("harmony activity list success");

								for (let activity of activityJson['activities']) {
									if (activity['isAVActivity'] == false) { continue; }

									var label = hubName + ' -> ' + activity['label'];
									var value = { "hubSlug": hub, "activitySlug": activity['slug'] }

									if (hub == currentHubSlug && activity['slug'] == currentActivitySlug) {
										uiconf.sections[0].content[0].value.value = value;
										uiconf.sections[0].content[0].value.label = label;

										uiconf.sections[0].content[0].options.unshift({ "value": value, "label": label });
									} else {
										uiconf.sections[0].content[0].options.push({ "value": value, "label": label });
									}
								}

								if (hubs[hubs.length - 1] == hub) { defer.resolve(uiconf); }
							})
							.catch(error => {
								self.logger.harmonycontroll('harmony activity list for ' + hub + ' error ' + error);
								defer.reject(error);
							});
						}
		  		})
		  		.catch(error => {
						self.logger.harmonycontroll('harmony hubs list error ' + error);
						defer.reject(error);
		  		});
        })
        .fail(function()
        {
            defer.reject(new Error());
        });

    return defer.promise;
};

harmonycontroll.prototype.saveOptions = function(data) {
    var self = this;

		let uiConfigActivityValue = data['activity_setting']['value']
		let hubSlug = uiConfigActivityValue['hubSlug']
		let activitySlug = uiConfigActivityValue['activitySlug']
		let offDelay = data['off_delay_setting']

		if(Number.isInteger(offDelay)) {
			self.logger.harmonycontroll('Saving Settings: hubSlug: ' + hubSlug)
			self.logger.harmonycontroll('Saving Settings: activitySlug: ' + activitySlug)
			self.logger.harmonycontroll('Saving Settings: sleepDelayAfterStop: ' + offDelay)

			self.config.set('hubSlug', hubSlug)
			self.config.set('activitySlug', activitySlug)
			self.config.set('sleepDelayAfterStop', offDelay)

			self.commandRouter.pushToastMessage('success', 'HarmonyControll Settings', 'Saved');
		} else {
			self.commandRouter.pushToastMessage('error', 'HarmonyControll Settings', 'Wrong value for off delay');
		}
};

harmonycontroll.prototype.getConfigurationFiles = function() {
	return ['config.json'];
}

harmonycontroll.prototype.setUIConfig = function(data) {
	var self = this;
	//Perform your installation tasks here
};

harmonycontroll.prototype.getConf = function(varName) {
	var self = this;
	//Perform your installation tasks here
};

harmonycontroll.prototype.setConf = function(varName, varValue) {
	var self = this;
	//Perform your installation tasks here
};
