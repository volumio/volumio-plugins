#!/bin/bash
echo "Now Playing plugin installed"
