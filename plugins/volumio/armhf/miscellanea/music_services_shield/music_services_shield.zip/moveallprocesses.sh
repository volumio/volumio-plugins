cset shield -c 0-0
/data/plugins/miscellanea/music_services_shield/moveprocess.sh mpd
/data/plugins/miscellanea/music_services_shield/moveprocess.sh vollibrespot

