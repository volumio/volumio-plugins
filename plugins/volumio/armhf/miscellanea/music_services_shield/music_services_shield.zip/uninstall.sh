#!/bin/bash

# Uninstall dependendencies
sudo apt-get remove -y cpuset

echo "Done"
echo "pluginuninstallend"

