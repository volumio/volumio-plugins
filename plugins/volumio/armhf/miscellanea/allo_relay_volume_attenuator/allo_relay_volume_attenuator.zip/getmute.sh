#!/bin/bash

echo volumio | sudo -S /usr/bin/r_attenuc -c GET_MUTE
