#!/bin/bash

echo "Removing gpio-control"
echo "pluginuninstallend"