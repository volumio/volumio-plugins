#!/bin/bash

echo "Installing gpio-control"

echo "plugininstallend"
