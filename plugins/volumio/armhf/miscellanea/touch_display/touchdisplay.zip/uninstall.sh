#!/bin/bash

echo "Unistalling gpiobuttons dependencies"

echo "Removing Touch display"

echo "Done"
