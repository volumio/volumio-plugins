#!/bin/bash

HW=$(awk '/VOLUMIO_HARDWARE=/' /etc/*-release | sed 's/VOLUMIO_HARDWARE=//' | sed 's/\"//g')

RASPI_ROTATE_VERSION="1.0"
SPLASH_DIRECTORY="/usr/share/plymouth/themes/volumio/"

if [ "$HW" = "pi" ];
then

  echo "Raspberry Pi install script"

  echo "Installing fake packages for kernel, bootloader and pi lib"
  wget http://repo.volumio.org/Volumio2/Binaries/arm/libraspberrypi0_0.0.1_all.deb
  wget http://repo.volumio.org/Volumio2/Binaries/arm/raspberrypi-bootloader_0.0.1_all.deb
  wget http://repo.volumio.org/Volumio2/Binaries/arm/raspberrypi-kernel_0.0.1_all.deb
  dpkg -i libraspberrypi0_0.0.1_all.deb
  dpkg -i raspberrypi-bootloader_0.0.1_all.deb
  dpkg -i raspberrypi-kernel_0.0.1_all.deb
  rm libraspberrypi0_0.0.1_all.deb
  rm raspberrypi-bootloader_0.0.1_all.deb
  rm raspberrypi-kernel_0.0.1_all.deb

  echo "Putting on hold packages for kernel, bootloader and pi lib"
  echo "libraspberrypi0 hold" | dpkg --set-selections
  echo "raspberrypi-bootloader hold" | dpkg --set-selections
  echo "raspberrypi-kernel hold" | dpkg --set-selections

  echo "Installing Chromium Dependencies"
  sudo apt-get update
  sudo apt-get -y install

  echo "Installing Graphical environment"
  sudo DEBIAN_FRONTEND=noninteractive apt-get install -y xinit xorg openbox libexif12 xserver-xorg-legacy

  echo "Installing Chromium"
  sudo apt-get install -y chromium-browser

  if [ -f /sys/devices/platform/rpi_backlight/backlight/rpi_backlight/brightness ]; then
    echo "Installing UDEV rule adjusting backlight brightness permissions"
    sudo echo "SUBSYSTEM==\"backlight\", RUN+=\"/bin/chmod 0666 /sys/devices/platform/rpi_backlight/backlight/rpi_backlight/brightness\"" > /etc/udev/rules.d/99-backlight.rules
    sudo /bin/chmod 0666 /sys/devices/platform/rpi_backlight/backlight/rpi_backlight/brightness
  fi

else

  echo "Installing Chromium Dependencies"
  sudo apt-get update
  sudo apt-get -y install

  echo "Installing Graphical environment"
  sudo DEBIAN_FRONTEND=noninteractive apt-get install -y xinit xorg openbox libexif12

  echo "Downloading Chromium"
  cd /home/volumio/
  wget http://launchpadlibrarian.net/234969703/chromium-browser_48.0.2564.82-0ubuntu0.15.04.1.1193_armhf.deb
  wget http://launchpadlibrarian.net/234969705/chromium-codecs-ffmpeg-extra_48.0.2564.82-0ubuntu0.15.04.1.1193_armhf.deb

  echo "Installing Chromium"
  sudo dpkg -i /home/volumio/chromium-*.deb
  sudo apt-get install -y -f
  sudo dpkg -i /home/volumio/chromium-*.deb

  rm /home/volumio/chromium-*.deb

fi

echo "Installing Japanese, Korean, Chinese and Taiwanese fonts"
sudo apt-get -y install fonts-arphic-ukai fonts-arphic-gbsn00lp fonts-unfonts-core

echo "Dependencies installed"

echo "Creating Kiosk Data dir"
mkdir /data/volumiokiosk
chown volumio:volumio /data/volumiokiosk

echo "Creating chromium kiosk start script"
sudo echo "#!/bin/bash
sed -i 's/\"exited_cleanly\":false/\"exited_cleanly\":true/' /data/volumiokiosk/Default/Preferences
sed -i 's/\"exit_type\":\"Crashed\"/\"exit_type\":\"None\"/' /data/volumiokiosk/Default/Preferences
openbox-session &
while true; do
  /usr/bin/chromium-browser \\
    --disable-pinch \\
    --kiosk \\
    --no-first-run \\
    --disable-3d-apis \\
    --disable-breakpad \\
    --disable-crash-reporter \\
    --disable-infobars \\
    --disable-session-crashed-bubble \\
    --disable-translate \\
    --user-data-dir='/data/volumiokiosk' \
	--no-sandbox \
    http://localhost:3000
done" > /opt/volumiokiosk.sh
sudo /bin/chmod +x /opt/volumiokiosk.sh

echo "Creating Systemd Unit for Kiosk"
sudo echo "[Unit]
Description=Volumio Kiosk
Wants=volumio.service
After=volumio.service
[Service]
Type=simple
User=volumio
Group=volumio
Restart=Always
ExecStart=/usr/bin/startx /etc/X11/Xsession /opt/volumiokiosk.sh -- -nocursor
# Give a reasonable amount of time for the server to start up/shut down
TimeoutSec=300
[Install]
WantedBy=multi-user.target
" > /lib/systemd/system/volumio-kiosk.service
sudo systemctl daemon-reload

echo "Allowing volumio to start an xsession"
sudo /bin/sed -i "s/allowed_users=console/allowed_users=anybody/" /etc/X11/Xwrapper.config

echo "Downloading raspi-rotate"
wget -O raspi-rotate-v${RASPI_ROTATE_VERSION}.tar.gz https://github.com/colinleroy/raspi-rotate/archive/v${RASPI_ROTATE_VERSION}.tar.gz
tar -xf raspi-rotate-v${RASPI_ROTATE_VERSION}.tar.gz
cd raspi-rotate-${RASPI_ROTATE_VERSION}

echo "Checking whether fbturbo is installed"
FBTURBO_OK=$(dpkg -L xserver-xorg-video-fbturbo|grep fbturbo_drv)
if [ "$FBTURBO_OK" != "" ]; then
    echo "Modifying template for fbturbo"
    sed -i "s/fbdev/fbturbo/" etc/xorg.conf.d/99-raspi-rotate.conf.tmpl
fi

echo "Installing make"
sudo apt-get install -y make

echo "Generating rotated boot splashscreens"
if [ ! -f "${SPLASH_DIRECTORY}/volumio-logo16-NORMAL.png" ]; then
        IMAGICK_INSTALLED=$(which convert)
        if [ "$IMAGICK_INSTALLED" = "" ]; then
                echo "Installing imagemagick"
                sudo apt-get install -y imagemagick
        fi
        sudo cp "${SPLASH_DIRECTORY}/volumio-logo16.png" "${SPLASH_DIRECTORY}/volumio-logo16-NORMAL.png"
        sudo rm "${SPLASH_DIRECTORY}/volumio-logo16.png"
        sudo cp "${SPLASH_DIRECTORY}/volumio-logo16-NORMAL.png" "${SPLASH_DIRECTORY}/volumio-logo16.png"

        sudo convert -rotate 90  "${SPLASH_DIRECTORY}/volumio-logo16.png" "${SPLASH_DIRECTORY}/volumio-logo16-CW.png"
        sudo convert -rotate 180 "${SPLASH_DIRECTORY}/volumio-logo16.png" "${SPLASH_DIRECTORY}/volumio-logo16-UD.png"
        sudo convert -rotate 270 "${SPLASH_DIRECTORY}/volumio-logo16.png" "${SPLASH_DIRECTORY}/volumio-logo16-CCW.png"

        if [ "$IMAGICK_INSTALLED" = "" ]; then
                echo "Removing imagemagick"
                sudo apt-get remove -y imagemagick
                sudo apt-get autoremove -y
        fi
fi

echo "Adding bootsplash hook"
cat > etc/hooks.d/01-bootsplash.sh << EOF
#!/bin/bash

if [ "\${ROTATE}" != "" ]; then
	if [ -f "${SPLASH_DIRECTORY}/volumio-logo16-\${ROTATE}.png" ]; then
		rm -f ${SPLASH_DIRECTORY}/volumio-logo16.png
		cp "${SPLASH_DIRECTORY}/volumio-logo16-\${ROTATE}.png" "${SPLASH_DIRECTORY}/volumio-logo16.png"
	fi
fi
EOF

echo "Installing raspi-rotate"
sudo make install
cd ..
echo "Cleaning up raspi-rotate source"
rm -rf raspi-rotate-${RASPI_ROTATE_VERSION} raspi-rotate-v${RASPI_ROTATE_VERSION}.tar.gz

#required to end the plugin install
echo "plugininstallend"
