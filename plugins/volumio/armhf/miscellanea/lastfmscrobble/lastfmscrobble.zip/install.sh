#!/bin/bash
echo "Installing lastfmscrobble Dependencies"
echo "plugininstallend"