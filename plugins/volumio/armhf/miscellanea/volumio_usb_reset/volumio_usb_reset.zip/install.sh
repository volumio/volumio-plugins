#!/bin/bash

echo "Installing volumio usb reset Dependencies"
sudo apt-get update
# Install the required packages via apt-get
sudo apt-get -y install

# If you need to differentiate install for armhf and i386 you can get the variable like this
#DPKG_ARCH=`dpkg --print-architecture`
# Then use it to differentiate your install

# Before finishing, we allow the volumio user to sudo the usbreset script without a password.

sudo sed -i '/USBResetScript/d' /etc/sudoers

echo 'volumio ALL = NOPASSWD: /home/volumio/volumio-plugins/plugins/miscellanea/volumio_usb_reset/USBResetScript/resetusb.sh' | sudo EDITOR='tee -a' visudo

#requred to end the plugin install
echo "plugininstallend"
