#!/bin/bash

echo "Installing 80s80s radio Dependencies"

#requred to end the plugin install
echo "plugininstallend"
