#!/bin/bash

echo "Installing swarmstation Dependencies"

#requred to end the plugin install
echo "plugininstallend"
