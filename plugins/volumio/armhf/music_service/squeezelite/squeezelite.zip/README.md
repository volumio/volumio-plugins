# volumio-squeezelite-plugin
Volumio plugin to install and configure a Squeezelite client

Not much to say about it, it's pretty straight forward.

It starts with default values:

-o default
-n Volumio
-a 80:4::
