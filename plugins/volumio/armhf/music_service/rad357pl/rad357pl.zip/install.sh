#!/bin/bash

echo "Installing radio 357 Dependencies"

#requred to end the plugin install
echo "plugininstallend"
