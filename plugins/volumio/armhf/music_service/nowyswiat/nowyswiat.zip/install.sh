#!/bin/bash

echo "Installing nowyswiat Dependencies"

#requred to end the plugin install
echo "plugininstallend"
