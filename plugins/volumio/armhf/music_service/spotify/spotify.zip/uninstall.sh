#!/bin/bash

echo "Unistalling Spop dependencies"

echo "Removing Spop"

while read -r filename; do
  rm "$filename"
done <spopuninstall.txt

echo "Done"

