#!/bin/bash

echo "Unistalling Spop dependencies"

echo "Removing Spop"

echo "Done"
echo "pluginuninstallend"