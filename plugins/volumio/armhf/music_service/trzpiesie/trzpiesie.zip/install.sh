#!/bin/bash

echo "Installing trzpiesie Dependencies"

#requred to end the plugin install
echo "plugininstallend"
