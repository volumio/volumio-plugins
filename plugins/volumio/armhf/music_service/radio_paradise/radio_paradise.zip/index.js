'use strict';

var libQ = require('kew');
var fs=require('fs-extra');
var config = new (require('v-conf'))();
var unirest = require('unirest');
// var exec = require('child_process').exec;
// var execSync = require('child_process').execSync;


module.exports = ControllerRadioParadise;

function ControllerRadioParadise(context) {
	var self = this;

	self.context = context;
	self.commandRouter = this.context.coreCommand;
	self.logger = this.context.logger;
    self.configManager = this.context.configManager;
    
    self.state = {};
    self.stateMachine = self.commandRouter.stateMachine;
    self.logger.info("ControllerRadioParadise::constructor");
};

ControllerRadioParadise.prototype.onVolumioStart = function()
{
	var self = this;
	var configFile=this.commandRouter.pluginManager.getConfigurationFile(this.context,'config.json');
	self.getConf(self.configFile);

    return libQ.resolve();
};

ControllerRadioParadise.prototype.getConfigurationFiles = function () {
    return ['config.json'];
  };

ControllerRadioParadise.prototype.onStart = function() {
    var self = this;
    //var defer=libQ.defer();
    
    self.mpdPlugin = this.commandRouter.pluginManager.getPlugin('music_service','mpd');

    self.logger.info('[' + Date.now() + '] ' + 'ControllerRadioParadise::onStart started');

    self.loadRadioI18nStrings();
    self.addRadioResource();
    self.addToBrowseSources();

    self.serviceName = "radio_paradise";

	// Once the Plugin has successfull started resolve the promise
	//defer.resolve();
    return libQ.resolve();
    //return defer.promise;
};

ControllerRadioParadise.prototype.onStop = function() {
    var self = this;
    var defer=libQ.defer();

    // Once the Plugin has successfull stopped resolve the promise
    defer.resolve();

    return libQ.resolve();
};

ControllerRadioParadise.prototype.onRestart = function() {
    var self = this;
    // Optional, use if you need it
    return libQ.resolve();
};


// Configuration Methods -----------------------------------------------------------------------------
ControllerRadioParadise.prototype.getUIConfig = function() {
    var defer = libQ.defer();
    var self = this;

    var lang_code = this.commandRouter.sharedVars.get('language_code');

    self.getConf(this.configFile);
    self.commandRouter.i18nJson(__dirname+'/i18n/strings_' + lang_code + '.json',
        __dirname + '/i18n/strings_en.json',
        __dirname + '/UIConfig.json')
    .then(function(uiconf)
    {
        defer.resolve(uiconf);
    })
    .fail(function()
    {
        defer.reject(new Error());
    });

    return defer.promise;
};


ControllerRadioParadise.prototype.setUIConfig = function(data) {
	var self = this;
	var uiconf=fs.readJsonSync(__dirname+'/UIConfig.json');

    return libQ.resolve();
};

ControllerRadioParadise.prototype.getConf = function(configFile) {
	var self = this;

    self.config = new (require('v-conf'))();
    self.config.loadFile(configFile);
};

ControllerRadioParadise.prototype.setConf = function(varName, varValue) {
	var self = this;
	fs.writeJsonSync(self.configFile, JSON.stringify(conf));
};



// Playback Controls ---------------------------------------------------------------------------------------
ControllerRadioParadise.prototype.addToBrowseSources = function () {
	// Use this function to add your music service plugin to music sources
    var self = this;

    self.commandRouter.volumioAddToBrowseSources({
        name: self.getRadioI18nString('PLUGIN_NAME'),
        uri: 'rparadise',
        plugin_type: 'music_service',
        plugin_name: "radio_paradise",
        albumart: '/albumart?sourceicon=music_service/radio_paradise/rp.svg'
    });
};

ControllerRadioParadise.prototype.handleBrowseUri = function (curUri) {
    var self = this;
    var response;
    if (curUri.startsWith('rparadise')) {
        if (curUri === 'rparadise') {
            response = self.getRootContent();
        }
        else if (curUri === 'rparadise/rparadise') {
            response = self.getRadioContent('rparadise');
        }
        else {
            response = libQ.reject();
        }
    }
    return response
    .fail(function (e) {
        self.logger.info('[' + Date.now() + '] ' + 'ControllerRadioParadise::handleBrowseUri failed');
        libQ.reject(new Error());
    });
};

ControllerRadioParadise.prototype.getRootContent = function() {
    var self=this;
    var response;
    var defer = libQ.defer();
  
    response = self.rootNavigation;
    response.navigation.lists[0].items = [];
    for (var key in self.rootStations) {
        var radio = {
          service: self.serviceName,
          type: 'folder',
          title: self.rootStations[key].title,
          icon: 'fa fa-folder-open-o',
          uri: self.rootStations[key].uri
        };
        response.navigation.lists[0].items.push(radio);
    }
    defer.resolve(response);
    return defer.promise;
  };

ControllerRadioParadise.prototype.getRadioContent = function(station) {
    var self=this;
    var response;
    var radioStation;
    var defer = libQ.defer();
  
    radioStation = self.radioStations.rparadise;
  
    response = self.radioNavigation;
    response.navigation.lists[0].items = [];
    for (var i in radioStation) {
      var channel = {
        service: self.serviceName,
        type: 'mywebradio',
        title: radioStation[i].title,
        artist: '',
        album: '',
        icon: 'fa fa-music',
        uri: radioStation[i].uri
      };
      response.navigation.lists[0].items.push(channel);
    }
    defer.resolve(response);
  
    return defer.promise;
  };

// Define a method to clear, add, and play an array of tracks
ControllerRadioParadise.prototype.clearAddPlayTrack = function(track) {
	var self = this;
    var defer = libQ.defer();

    return self.mpdPlugin.sendMpdCommand('stop', [])
        .then(function() {
            return self.mpdPlugin.sendMpdCommand('clear', []);
        })
        .then(function() {
            return self.mpdPlugin.sendMpdCommand('add "'+track.uri+'"',[]);
        })
        .then(function () {
            self.commandRouter.pushToastMessage('info',
                self.getRadioI18nString('PLUGIN_NAME'),
                self.getRadioI18nString('WAIT_FOR_RADIO_CHANNEL'));

            return self.mpdPlugin.sendMpdCommand('play', []).then(function () {
                self.commandRouter.stateMachine.setConsumeUpdateService('mpd');
                return libQ.resolve();
            })
        })
        .fail(function (e) {
            return defer.reject(new Error());
        });
};

//TODO: for some reason this crashes volumio
ControllerRadioParadise.prototype.seek = function (position) {
    this.commandRouter.pushConsoleMessage('[' + Date.now() + '] ' + 'ControllerRadioParadise::seek to ' + position);

    return self.mpdPlugin.seek(position);
};

// Stop
ControllerRadioParadise.prototype.stop = function() {
	var self = this;
    self.commandRouter.pushConsoleMessage('[' + Date.now() + '] ' + 'ControllerRadioParadise::stop');
    self.commandRouter.pushToastMessage(
        'info',
        self.getRadioI18nString('PLUGIN_NAME'),
        self.getRadioI18nString('STOP_RADIO_CHANNEL')
    );
    return self.mpdPlugin.stop().then(function () {
        return self.mpdPlugin.getState().then(function (state) {
            return self.commandRouter.stateMachine.syncState(state, self.serviceName);
        });
    });
};

// Pause
ControllerRadioParadise.prototype.pause = function() {
	var self = this;
    self.commandRouter.pushConsoleMessage('[' + Date.now() + '] ' + 'ControllerRadioParadise::pause');
    return self.mpdPlugin.pause().then(function () {
        return self.mpdPlugin.getState().then(function (state) {
            return self.commandRouter.stateMachine.syncState(state, self.serviceName);
        });
    });
};

// Resume
ControllerRadioParadise.prototype.resume = function() {
    var self = this;
  
    return self.mpdPlugin.resume().then(function () {
      return self.mpdPlugin.getState().then(function (state) {
          return self.commandRouter.stateMachine.syncState(state, self.serviceName);
      });
    });
  };

// Get state
ControllerRadioParadise.prototype.getState = function() {
	var self = this;
	self.commandRouter.pushConsoleMessage('[' + Date.now() + '] ' + 'ControllerRadioParadise::getState');


};

// Parse state
ControllerRadioParadise.prototype.parseState = function(sState) {
	var self = this;
	self.commandRouter.pushConsoleMessage('[' + Date.now() + '] ' + 'ControllerRadioParadise::parseState');

	//Use this method to parse the state and eventually send it with the following function
};

// Announce updated State
ControllerRadioParadise.prototype.pushState = function(state) {
	var self = this;
	self.commandRouter.pushConsoleMessage('[' + Date.now() + '] ' + 'ControllerRadioParadise::pushState');

	return self.commandRouter.servicePushState(state, self.servicename);
};

ControllerRadioParadise.prototype.explodeUri = function(uri) {
	var self = this;
	var defer=libQ.defer();
    var uris = uri.split("/");
    var channel = parseInt(uris[1]);
    var response = [];
    var query;
    var station;

    station = uris[0].substring(3);

    switch (uris[0]) {
        case 'webrp':
            if(channel === 0) {
                var url = 'https://api.radioparadise.com/api/get_block?bitrate=4&info=true';
                var streamLength = 0;
                var nextEventStreamUrl;
                // FLAC option chosen, getting first event
                self.getStream(url).then(function (eventResponse) {
                    if (eventResponse  !== null) {
                        var result = JSON.parse(eventResponse);
                        var streamUrl = result.url;
                
                        if (streamUrl === undefined) {
                            streamUrl = null;
                            self.errorToast(station, 'INCORRECT_RESPONSE');
                        }
                        // the first stream event url to play
                        streamUrl = result.url+'?src=alexa';

                        response.push({
                            service: self.serviceName,
                            type: 'track',
                            trackType: self.getRadioI18nString('PLUGIN_NAME'),
                            radioType: station,
                            albumart: '/albumart?sourceicon=music_service/radio_paradise/rp-cover.png',
                            uri: streamUrl,
                            name: 'Radio Paradise FLAC',
                            title: 'Radio Paradise FLAC 1'
                        });
                        // the length of the first event in seconds
                        streamLength = result.length;
                        // the url needed to retrieve the next stream event
                        nextEventStreamUrl = url + '&event=' + result.end_event;
                    }
                    defer.resolve(response);
                 }).then(function () {
                    self.logger.info('[' + Date.now() + '] ' + 'first event playtime: ' + streamLength);
                    self.logger.info('[' + Date.now() + '] ' + 'next event stream url: ' + nextEventStreamUrl);
                    self.getStream(nextEventStreamUrl).then(function (nextEventResponse) {
                        var result = JSON.parse(nextEventResponse);
                        var streamUrl = result.url+'?src=alexa';
                        response.push({
                            service: self.serviceName,
                            type: 'track',
                            trackType: self.getRadioI18nString('PLUGIN_NAME'),
                            radioType: station,
                            albumart: '/albumart?sourceicon=music_service/radio_paradise/rp-cover.png',
                            uri: streamUrl,
                            name: 'Radio Paradise FLAC',
                            title: 'Radio Paradise FLAC 2'
                        });
                        self.logger.info('[' + Date.now() + '] ' + 'SECOND event successfully pushed tp response.');
                        defer.resolve(response);
                    });
                });
            } else {
                // normal streams with static url from radio_stations.json
                response.push({
                    service: self.serviceName,
                    type: 'track',
                    trackType: self.getRadioI18nString('PLUGIN_NAME'),
                    radioType: station,
                    albumart: '/albumart?sourceicon=music_service/radio_paradise/rp-cover.png',
                    uri: self.radioStations.rparadise[channel].url,
                    name: self.radioStations.rparadise[channel].title
                });
                defer.resolve(response);
            }
            break;
        default:
            defer.resolve();
    }
    return defer.promise;
};

// ControllerRadioParadise.prototype.getAlbumArt = function (data, path) {

// 	var artist, album;

// 	if (data != undefined && data.path != undefined) {
// 		path = data.path;
// 	}

// 	var web;

// 	if (data != undefined && data.artist != undefined) {
// 		artist = data.artist;
// 		if (data.album != undefined)
// 			album = data.album;
// 		else album = data.artist;

// 		web = '?web=' + nodetools.urlEncode(artist) + '/' + nodetools.urlEncode(album) + '/large'
// 	}

// 	var url = '/albumart';

// 	if (web != undefined)
// 		url = url + web;

// 	if (web != undefined && path != undefined)
// 		url = url + '&';
// 	else if (path != undefined)
// 		url = url + '?';

// 	if (path != undefined)
// 		url = url + 'path=' + nodetools.urlEncode(path);

// 	return url;
// };

ControllerRadioParadise.prototype.addRadioResource = function() {
    var self=this;
  
    var radioResource = fs.readJsonSync(__dirname+'/radio_stations.json');
    var baseNavigation = radioResource.baseNavigation;
  
    self.rootStations = radioResource.rootStations;
    self.radioStations = radioResource.stations;
    self.rootNavigation = JSON.parse(JSON.stringify(baseNavigation));
    self.radioNavigation = JSON.parse(JSON.stringify(baseNavigation));
    self.rootNavigation.navigation.prev.uri = '/';
};

ControllerRadioParadise.prototype.getStream = function (url) {
    var self=this;
    self.logger.info('[' + Date.now() + '] ' + 'ControllerRadioParadise::getStream started');
    var self = this;
    var defer = libQ.defer();

    var Request = unirest.get(url);
    Request
      .end(function (response) {
        if (response.status === 200) {
            self.logger.info('[' + Date.now() + '] ' + 'ControllerRadioParadise::getStream request-successful');
            defer.resolve(response.body);
        }
        else {
            defer.resolve(null);
            self.errorToast(station, 'ERROR_STREAM_SERVER');
        }
      });

    return defer.promise;
};

ControllerRadioParadise.prototype.loadRadioI18nStrings = function () {
    var self=this;
    self.i18nStrings=fs.readJsonSync(__dirname+'/i18n/strings_en.json');
    self.i18nStringsDefaults=fs.readJsonSync(__dirname+'/i18n/strings_en.json');
};

ControllerRadioParadise.prototype.getRadioI18nString = function (key) {
    var self=this;

    if (self.i18nStrings[key] !== undefined)
        return self.i18nStrings[key];
    else
        return self.i18nStringsDefaults[key];
};

ControllerRadioParadise.prototype.search = function (query) {
	var self=this;
	var defer=libQ.defer();

	// Mandatory, search. You can divide the search in sections using following functions
    defer.resolve();
	return defer.promise;
};

ControllerRadioParadise.prototype.errorToast = function (station, msg) {
    var errorMessage = self.getRadioI18nString(msg);
    errorMessage.replace('{0}', station.toUpperCase());
    self.commandRouter.pushToastMessage('error',
        self.getRadioI18nString('PLUGIN_NAME'), errorMessage);
};
