#!/usr/bin/env bash
./usr/bin/vollibrespot \
    -c /tmp/volspotify.toml
    # --verbose
