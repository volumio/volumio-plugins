# volumio-personal-radio-plugin
Korean Radio Stations(KBS, MBC, SBS) and Linn Radio plugin for Volumio.

- KBS(Korean Broadcasting System): commercial broadcaster in Korea
- MBC(Munhwa Broadcasting Corporation): commercial broadcaster in Korea
- SBS(Seoul Broadcasting System): commercial broadcaster in Korea
- Linn: Highest quality web radio that includes radio, classical, jazz chanel stations