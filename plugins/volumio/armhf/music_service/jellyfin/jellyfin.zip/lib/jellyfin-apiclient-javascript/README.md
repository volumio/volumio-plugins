Files in this directory are taken from [Jellyfin API Client for JavaScript](https://github.com/jellyfin/jellyfin-apiclient-javascript) (v1.4.2). 

They have been modified slightly for use with Volumio.