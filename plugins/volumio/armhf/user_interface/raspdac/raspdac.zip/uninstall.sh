#!/bin/bash

echo "Unistalling raspdac dependencies"

echo "pluginuninstallend"
