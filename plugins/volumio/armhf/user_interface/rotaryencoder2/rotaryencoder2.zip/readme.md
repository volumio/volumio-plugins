# RotaryEncoder II
Alternative implementation of Rotary Encoder controls using the Linux Kernel driver for Rotaries.

Documentation can be found [here](https://volumio.github.io/docs/Plugins_User_Manuals/rotaryencoder2/Rotary_Encoder_II.html).
