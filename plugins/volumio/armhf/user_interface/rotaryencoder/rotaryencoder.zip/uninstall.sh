#!/bin/bash

echo "No packages have been installed for this plugin."

echo "pluginuninstallend"