#!/bin/bash

echo "Removing gpio_control"
echo "pluginuninstallend"