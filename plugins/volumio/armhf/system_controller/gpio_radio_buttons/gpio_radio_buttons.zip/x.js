'use strict';

var libQ = require('kew');
var fs = require('fs-extra');
var Gpio = require('onoff').Gpio;
var io = require('socket.io-client');
var socket = io.connect('http://localhost:3000');
var buttons = ["radioOne"];


console.log("Issue browse request");
socket.emit('browseLibrary', { uri: 'radio/favourites' } );

socket.once('pushBrowseLibrary', function(data) {
		console.log('========================');
		// console.log(JSON.stringify(data));
		// console.log(typeof data.navigation.lists[0].items[0]);
		// console.log(data.navigation.lists[0].items[0].title);
		// console.log(data.navigation.lists[0].items[0].uri);
		data.navigation.lists[0].items.forEach(function(item, index, array){
			console.log("Title: " + item.title + " with uri " + item.uri);
		});
		console.log('========================');

var config = new (require('v-conf'))();
config.loadFile('config.json');

config.print();

console.log(config.get("separator"));
console.log(config.get('gpioPins'));
console.log(config.get('radioOne'));


});

