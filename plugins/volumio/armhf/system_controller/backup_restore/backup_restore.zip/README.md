# Backup & Restore Plugin

Get the latest install file from [here](https://github.com/macmpi/volumio-plugins/raw/gh-pages/plugins/volumio/armhf/system_controller/backup_restore/backup_restore.zip)


## changelog:
0.7.2:  (August 10th 2017)
- Fix issue with French locale file


0.7.1:  (August 5th 2017)
- Configuration backup disabled by default
- doc update


0.7.0:  (July 13th 2017)
- added restart dialog after Restore


0.6.7:  (July 13th 2017)
- protect against rare cases where some elements (queue) may not exist yet


0.6.5:  (July 12th 2017)
- UI tweaks
- code cleanup


0.6.0:  (July 11th 2017)
- optimized compression
- Archive file is now on SMB share for easier access

  
0.5.0:  (July 10th 2017)
- initial release
- Archive file is on SD

