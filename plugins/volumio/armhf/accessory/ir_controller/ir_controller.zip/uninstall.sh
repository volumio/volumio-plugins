#!/bin/bash

echo "Unistalling LIRC"

apt-get -y purge lirc

echo "Done"
