#!/bin/bash
wget "localhost:3000/api/v1/commands/?cmd=stop"