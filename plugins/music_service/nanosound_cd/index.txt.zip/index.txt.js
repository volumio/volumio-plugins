'use strict';

var libQ = require('kew');
var fs=require('fs-extra');
var config = new (require('v-conf'))();
var exec = require('child_process').exec;
var execSync = require('child_process').execSync;
var request = require("request")

module.exports = nanosoundCd;
function nanosoundCd(context) {
	var self = this;

	this.context = context;
	this.commandRouter = this.context.coreCommand;
	this.logger = this.context.logger;
	this.configManager = this.context.configManager;
	self.servicename = 'nanosound_cd';
	self.samplerate = '44.1 -> 176.4khz'
	self.tracktype = 'NanoSound CD'
}



nanosoundCd.prototype.onVolumioStart = function()
{
	var self = this;
	var configFile=this.commandRouter.pluginManager.getConfigurationFile(this.context,'config.json');
	this.config = new (require('v-conf'))();
	this.config.loadFile(configFile);

    return libQ.resolve();
}

nanosoundCd.prototype.onStart = function() {
    var self = this;
	var defer=libQ.defer();

	self.addToBrowseSources();
	// Once the Plugin has successfull started resolve the promise
	defer.resolve();

    return defer.promise;
};

nanosoundCd.prototype.onStop = function() {
    var self = this;
    var defer=libQ.defer();

    // Once the Plugin has successfull stopped resolve the promise
    defer.resolve();

    return libQ.resolve();
};

nanosoundCd.prototype.onRestart = function() {
    var self = this;
    // Optional, use if you need it
};


// Configuration Methods -----------------------------------------------------------------------------

nanosoundCd.prototype.getUIConfig = function() {
    var defer = libQ.defer();
    var self = this;

    var lang_code = this.commandRouter.sharedVars.get('language_code');

    self.commandRouter.i18nJson(__dirname+'/i18n/strings_'+lang_code+'.json',
        __dirname+'/i18n/strings_en.json',
        __dirname + '/UIConfig.json')
        .then(function(uiconf)
        {


            defer.resolve(uiconf);
        })
        .fail(function()
        {
            defer.reject(new Error());
        });

    return defer.promise;
};

nanosoundCd.prototype.getConfigurationFiles = function() {
	return ['config.json'];
}

nanosoundCd.prototype.setUIConfig = function(data) {
	var self = this;
	//Perform your installation tasks here
};

nanosoundCd.prototype.getConf = function(varName) {
	var self = this;
	//Perform your installation tasks here
};

nanosoundCd.prototype.setConf = function(varName, varValue) {
	var self = this;
	//Perform your installation tasks here
};



// Playback Controls ---------------------------------------------------------------------------------------
// If your plugin is not a music_sevice don't use this part and delete it


nanosoundCd.prototype.addToBrowseSources = function () {

	// Use this function to add your music service plugin to music sources
    //var data = {name: 'Spotify', uri: 'spotify',plugin_type:'music_service',plugin_name:'spop'};
	var data = {name: 'NanoSound CD', uri: 'nanosound_cd',plugin_type:'music_service',plugin_name:'nanosound_cd', albumart: '/albumart?sourceicon=music_service/nanosound_cd/nanosoundcd.svg'};


    this.commandRouter.volumioAddToBrowseSources(data);
};

nanosoundCd.prototype.listCD=function()
{
	var defer=libQ.defer();
	
	var url = "http://127.0.0.1:5002/cdmeta2"
	request({
	url: url,
	json: true
	}, function (error, httpresponse, body) {

		if (!error && httpresponse.statusCode === 200) {
			var cdmeta = body
			var response={
				navigation: {
					prev: {
						uri: 'nanosound_cd'
					},
					"lists": [
						{
							"availableListViews": [
								"list"
							],
							"items": [

								{
									service: 'nanosound_cd',
									type: 'folder',
									title: '[Whole CD]',
									artist: cdmeta[0]['artist_name'],
									album: cdmeta[0]['album_name'],
									icon: 'fa fa-music',
									uri: 'nanosound_cd/playall'
								}
							]
						}
					]
				}
			};

			var i;
			for(i = 0; i< cdmeta.length ; i++)
			{
				response.navigation.lists[0].items.push({
					service: 'nanosound_cd',
					type: 'song',
					title: cdmeta[i]['track_name'],
					artist:cdmeta[i]['artist_name'],
					album: cdmeta[i]['album_name'],
					icon: 'fa fa-music',
					uri: 'nanosound_cd/' + cdmeta[i]['track_number']
				});
			}

			console.log(cdmeta.length) // Print the json response
			defer.resolve(response);
			//cdmeta = body[0]
			//var items = []
			/*for (songmeta in cdmeta)
			{
				
			}*/
		}
	})

	return defer.promise;
}

nanosoundCd.prototype.handleBrowseUri = function (curUri) {
    var self = this;

    //self.commandRouter.logger.info(curUri);
    var response;
	
	if (curUri.startsWith('nanosound_cd')) {
	    if (curUri == 'nanosound_cd') {
			response = self.listCD();
        }
    }


    return response;
};



// Define a method to clear, add, and play an array of tracks
nanosoundCd.prototype.clearAddPlayTrack = function(track) {
	var self = this;
	var defer = libQ.defer();
	
	self.commandRouter.pushConsoleMessage('[' + Date.now() + '] ' + 'nanosoundCd::clearAddPlayTrack');
	self.commandRouter.logger.info(JSON.stringify(track));
	
	var uriSplitted=track.uri.split('/');
	var trackno = uriSplitted[1];
	//self.commandRouter.logger.info('play:' + trackno);
	var url = "http://127.0.0.1:5002/playtrack?usecachedmeta=True&track=" + trackno
	request({
	url: url,
	json: true
	}, function (error, httpresponse, body) {

		if(body["status"]!="ERROR")
		{

			//get track info from body
			var rpState = {
			status: 'play',
			service: 'nanosound_cd',
			type: 'track',
			trackType: self.tracktype,
			uri: track.uri,
			name: track.name,
			title: track.title,
			streaming: false,
			artist: track.artist,
			album: track.album,
			duration: body["length"],
			seek: 0,
			samplerate: self.samplerate,
			bitdepth: '16 bit',
			channels: 2
			};

			self.state = rpState;

			//workaround to allow state to be pushed when not in a volatile state
			var vState = self.commandRouter.stateMachine.getState();
			var queueItem = self.commandRouter.stateMachine.playQueue.arrayQueue[vState.position];

			queueItem.name = track.name;
			queueItem.artist = track.artist;
			queueItem.album = track.album;
			queueItem.trackType = self.tracktype;
			queueItem.duration = body["length"];
			queueItem.samplerate = self.samplerate;
			queueItem.bitdepth = '16 bit';
			queueItem.channels = 2;
			queueItem.streaming = false;


			self.commandRouter.stateMachine.currentSeek = 0;
			self.commandRouter.stateMachine.playbackStart=Date.now();
			self.commandRouter.stateMachine.currentSongDuration=body["length"];
			self.commandRouter.stateMachine.askedForPrefetch=false;
			self.commandRouter.stateMachine.prefetchDone=false;
			self.commandRouter.stateMachine.simulateStopStartDone=false;
			self.commandRouter.logger.info("curduration:" + body["length"]);

			self.state = rpState;
			self.commandRouter.servicePushState(rpState, 'nanosound_cd');
		}
		return libQ.resolve(rpState)
	})

	
	
	return defer.promise;
	
	/*r.pushConsoleMessage('[' + Date.now() + '] ' + 'nanosoundCd::clearAddPlayTrack');
	self.commandRouter.logger.info(JSON.stringify(track));

	return self.sendSpopCommand('uplay', [track.uri]);*/
};

nanosoundCd.prototype.seek = function (timepos) {
    this.commandRouter.pushConsoleMessage('[' + Date.now() + '] ' + 'nanosoundCd::seek to ' + timepos);

    return this.sendSpopCommand('seek '+timepos, []);
};

// Stop
nanosoundCd.prototype.stop = function() {
	var self = this;

	self.commandRouter.pushConsoleMessage('[' + Date.now() + '] ' + 'nanosoundCd::stop');
	if (self.timer) {
        self.timer.clear();
    }
	//self.commandRouter.logger.info('play:' + trackno);
	var url = "http://127.0.0.1:5002/stop2"
	var defer = libQ.defer();
	request({
	url: url,
	json: true
	}, function (error, httpresponse, body) {

		if(body["status"]!="ERROR")
		{

			//get track info from body
			var rpState = {
			status: 'stop'
			};

			self.state = rpState;
			self.commandRouter.servicePushState(rpState, 'nanosound_cd');
		}
		defer.resolve();
	});
	return defer.promise;
};

nanosoundCd.prototype.resume = function() {
	var self = this;
	self.commandRouter.pushConsoleMessage('[' + Date.now() + '] ' + 'nanosoundCd::resume');
	var defer = libQ.defer();
	var url = "http://127.0.0.1:5002/playtoggle2"
	request({
	url: url,
	json: true
	}, function (error, httpresponse, body) {

		if(body["status"]!="ERROR")
		{
			var statusst='play'
			if(body["status"]=="State.Paused")
				statusst='pause'

			if(body["status"]=="State.Playing")
				statusst='play'

			//get track info from body
			var rpState = {
			status: statusst,
			service: 'nanosound_cd',
			type: 'track',
			streaming: false,
			trackType: self.tracktype,
			duration: body["length"],
			samplerate: self.samplerate,
			bitdepth: '16 bit',
			channels: 2
			};

			self.state = rpState;
			self.commandRouter.servicePushState(rpState, 'nanosound_cd');
		}
		defer.resolve();
	})

	return defer.promise;
};


// Spop pause
nanosoundCd.prototype.pause = function() {
	var self = this;
	self.commandRouter.pushConsoleMessage('[' + Date.now() + '] ' + 'nanosoundCd::pause');
	var defer = libQ.defer();
	var url = "http://127.0.0.1:5002/playtoggle2"
	request({
	url: url,
	json: true
	}, function (error, httpresponse, body) {

		if(body["status"]!="ERROR")
		{
			var statusst='play'
			if(body["status"]=="State.Paused")
				statusst='pause'

			if(body["status"]=="State.Playing")
				statusst='play'

			//get track info from body
			var rpState = {
			status: statusst,
			service: 'nanosound_cd',
			type: 'track',
			streaming: false,
			trackType: self.tracktype,
			duration: body["length"],
			samplerate: self.samplerate,
			bitdepth: '16 bit',
			channels: 2
			};

			self.state = rpState;
			self.commandRouter.servicePushState(rpState, 'nanosound_cd');
		}
		defer.resolve();
	})
	return defer.promise;
};

// Get state
nanosoundCd.prototype.getState = function() {
	var self = this;
	self.commandRouter.pushConsoleMessage('[' + Date.now() + '] ' + 'nanosoundCd::getState');


};

//Parse state
nanosoundCd.prototype.parseState = function(sState) {
	var self = this;
	self.commandRouter.pushConsoleMessage('[' + Date.now() + '] ' + 'nanosoundCd::parseState');

	//Use this method to parse the state and eventually send it with the following function
};

// Announce updated State
nanosoundCd.prototype.pushState = function(state) {
	var self = this;
	self.commandRouter.pushConsoleMessage('[' + Date.now() + '] ' + 'nanosoundCd::pushState');

	return self.commandRouter.servicePushState(state, self.servicename);
};


nanosoundCd.prototype.explodeUri = function(uri) {
	var self = this;
	var defer=libQ.defer();

	// Mandatory: retrieve all info for a given URI
	var uriSplitted;
	

	self.logger.info("exploding")
	var url = "http://127.0.0.1:5002/cachedcdmeta"
	request({
	url: url,
	json: true
	}, function (error, httpresponse, body) {
		
		var cachedmeta = body
		
		if (!error && httpresponse.statusCode === 200) {
			if (uri.startsWith('nanosound_cd/playall')) {
				var response=[];

				for(i=0;i<cachedmeta.length;i++)
				{
					var item={
						uri:  'nanosound_cd/' + cachedmeta[i]['track_number'],
						service: 'nanosound_cd',
						type: 'song',
						name:  cachedmeta[i]['track_name'],
						title: cachedmeta[i]['track_name'],
						artist:cachedmeta[i]['artist_name'],
						album: cachedmeta[i]['album_name'],
						streaming: false,
						//duration: 10,
						albumart: '/albumart?sourceicon=music_service/nanosound_cd/nanosoundcd.svg',
						samplerate: self.samplerate,
						bitdepth: '16 bit',
						trackType: self.tracktype
			
					};
				
					response.push(item);
				}
				defer.resolve(response);
			}
			else if (uri.startsWith('nanosound_cd/')) {
				uriSplitted=uri.split('/');
				var trackno = uriSplitted[1];
				console.log(trackno)
				var response=[];
				var item={
					uri: 'nanosound_cd/' + trackno,
					service: 'nanosound_cd',
					type: 'song',
					name:  cachedmeta[trackno-1]['track_name'],
					title: cachedmeta[trackno-1]['track_name'],
					artist:cachedmeta[trackno-1]['artist_name'],
					album: cachedmeta[trackno-1]['album_name'],
					albumart: '/albumart?sourceicon=music_service/nanosound_cd/nanosoundcd.svg',
					streaming: false,
					//duration: 10,
					//duration: resJson.tracks[i]x`.duration/1000,
					//albumart: albumart,
					samplerate: self.samplerate,
					bitdepth: '16 bit',
					trackType: self.tracktype
		
				};
				response.push(item);
				defer.resolve(response);
			}
		
		}
	})
	return defer.promise;
};

nanosoundCd.prototype.getAlbumArt = function (data, path) {

	var artist, album;

	if (data != undefined && data.path != undefined) {
		path = data.path;
	}

	var web;

	if (data != undefined && data.artist != undefined) {
		artist = data.artist;
		if (data.album != undefined)
			album = data.album;
		else album = data.artist;

		web = '?web=' + nodetools.urlEncode(artist) + '/' + nodetools.urlEncode(album) + '/large'
	}

	var url = '/albumart';

	if (web != undefined)
		url = url + web;

	if (web != undefined && path != undefined)
		url = url + '&';
	else if (path != undefined)
		url = url + '?';

	if (path != undefined)
		url = url + 'path=' + nodetools.urlEncode(path);

	return url;
};





nanosoundCd.prototype.search = function (query) {
	var self=this;
	var defer=libQ.defer();

	// Mandatory, search. You can divide the search in sections using following functions

	return defer.promise;
};

nanosoundCd.prototype._searchArtists = function (results) {

};

nanosoundCd.prototype._searchAlbums = function (results) {

};

nanosoundCd.prototype._searchPlaylists = function (results) {


};

nanosoundCd.prototype._searchTracks = function (results) {

};
