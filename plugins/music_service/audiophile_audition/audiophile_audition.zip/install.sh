#!/bin/bash

echo "Installing audiophile audition Dependencies"

#requred to end the plugin install
echo "plugininstallend"
