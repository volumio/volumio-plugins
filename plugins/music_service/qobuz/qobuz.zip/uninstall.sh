#!/bin/bash

echo "Unistalling Qobuz dependencies"

echo "Removing Qobuz"

echo "Done"
echo "pluginuninstallend"