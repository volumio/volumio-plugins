This plugin allows any subsonic API (>1.13.0) capable server (subsonic / airsonic / etc..) to be used as a backend for Volumio. 

Main menu provide:
* Randoms albums
* Newest albums
* Genres
* Artists
* Playlists
* Podcasts

Albums special feature
* LastFM infos when available

Artists Specials Features
* LastFM infos when available
* Radio mode: generate a playlist of similar tracks present on the backend
* Top songs as defined on lastFM and present on the backend
* Links to similar artists present on the backend
