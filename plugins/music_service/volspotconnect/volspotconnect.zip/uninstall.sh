#!/bin/bash

echo "Uninstalling volspotconnect dependencies"
sudo rm -Rf /data/configuration/music_service/volspotconnect/
sudo rm -Rf /data/plugins/music_service/volspotconnect/
echo "Removing volspotconnect"
echo " Removing voslpotconnect configuration file"

echo "Done"
echo "pluginuninstallend"
