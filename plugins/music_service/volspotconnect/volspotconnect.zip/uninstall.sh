#!/bin/bash

echo "Unistalling volspotconnect dependencies"

echo "Removing volspotconnect"

echo "Done"
echo "pluginuninstallend"
