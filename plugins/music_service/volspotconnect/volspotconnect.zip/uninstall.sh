#!/bin/bash

echo "Unistalling volspotconnect dependencies"

echo "Removing volspotconnect"
echo " Removing voslpotconnect configuration file"
rm -Rf /data/configuration/music_service/volspotconnect/

echo "Done"
echo "pluginuninstallend"
