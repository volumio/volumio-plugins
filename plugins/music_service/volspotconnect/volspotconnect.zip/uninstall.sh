#!/bin/bash

echo "Unistalling volspotconnect dependencies"

echo "Removing volspotconnect"
sudo rm -Rf /data/configuration/music_service/volspotconnect/
sudo rm -Rf /data/plugins/music_service/volspotconnect/
echo " Removing voslpotconnect configuration file"

echo "Done"
echo "pluginuninstallend"
