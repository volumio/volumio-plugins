#!/bin/bash

/bin/umount -lf /data/plugins/music_service/volspotconnect/spotify-connect-web/dev
/bin/umount -lf /data/plugins/music_service/volspotconnect/spotify-connect-web/proc

