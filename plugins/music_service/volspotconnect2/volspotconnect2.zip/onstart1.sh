#!/bin/bash
sudo rm /data/plugins/music_service/volspotconnect2/c2/*
systemctl restart volspotconnect22.service
