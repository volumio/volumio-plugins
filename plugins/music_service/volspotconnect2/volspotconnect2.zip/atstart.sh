#!/bin/bash
rm /tmp/credentials.json
