#!/bin/bash

echo "Uninstalling volspotconnect2 dependencies"
sudo rm /etc/systemd/system/volspotconnect2*
echo "Removing volspotconnect2"

echo "Done"
echo "pluginuninstallend"
