#!/bin/bash
sudo rm /data/plugins/music_service/volspotconnect2/c1/*
systemctl restart volspotconnect2.service
