January 21th 2017
	VOLUMIO SPOTIFY CONNECT 2 PLUGIN

This new version use librespot https://github.com/plietar/librespot
If it works as expected, it will remplace volspotconnect


IMPORTANT

- Requires a Premium or Family account

To install
- You only need to download volspotconnect2.zip. Take care to download the "raw" file, not only html from github...
- From Volumio UI choose "plugins" in setting, then "upload plugin" and select the file you have downloaded

Last changes

January 21th

new work - first almost working plugin
remove x bit on service

January 20th

- First commit

Issues : 

Todo

- Add album art and working button in volumio UI
