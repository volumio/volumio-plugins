#!/bin/bash
sudo rm /tmp/credentials.json
systemctl restart volspotconnect2.service
