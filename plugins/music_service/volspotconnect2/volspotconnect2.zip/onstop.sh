#!/bin/bash
sudo rm /tmp/credentials.json
